"""nm-portable CLI."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .core import ProfileUnreadable, WouldOverwriteSource, audit_directory, audit_profile, write_portable_copy
from .style import resolve_style, status_headline


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="nm-portable",
        description=(
            "Find and fix NetworkManager .nmconnection profiles that are pinned "
            "to specific hardware (MAC address, interface name), so they can be "
            "safely copied to a different machine."
        ),
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    audit = sub.add_parser("audit", help="Report portability blockers, change nothing.")
    audit.add_argument("path", type=Path, help="A .nmconnection file or a directory containing them.")
    audit.add_argument("--json", action="store_true", help="Emit machine-readable JSON.")
    audit.add_argument("--no-color", action="store_true", help="Disable colored output.")

    fix = sub.add_parser("fix", help="Write portable copies with hardware pins removed.")
    fix.add_argument("path", type=Path, help="A .nmconnection file or a directory containing them.")
    fix.add_argument("--out", type=Path, required=True, help="Output directory for portable copies.")
    fix.add_argument(
        "--strip-static-ip", action="store_true",
        help="Also reset static IPv4/IPv6 configuration to 'auto' (off by default).",
    )
    fix.add_argument("--json", action="store_true", help="Emit machine-readable JSON.")
    fix.add_argument("--no-color", action="store_true", help="Disable colored output.")

    return p


def _collect_paths(path: Path) -> list:
    if path.is_dir():
        return sorted(path.glob("*.nmconnection"))
    return [path]


def _cmd_audit(args) -> int:
    paths = _collect_paths(args.path)
    reports = [audit_profile(p) for p in paths]
    any_blockers = any(r.has_portability_blockers for r in reports)

    if args.json:
        payload = [
            {
                "path": str(r.path),
                "has_portability_blockers": r.has_portability_blockers,
                "readable": r.readable,
                "unreadable_reason": r.unreadable_reason,
                "findings": [{"level": f.level, "field": f.field, "message": f.message} for f in r.findings],
            }
            for r in reports
        ]
        print(json.dumps(payload, indent=2))
    else:
        style = resolve_style(no_color_flag=args.no_color)
        if not reports:
            print(f"No .nmconnection files found at {args.path}")
        for r in reports:
            print(f"\n{r.path}")
            if not r.readable:
                print(f"  {status_headline(style, 'warn', f'could not inspect this file: {r.unreadable_reason}')}")
                continue
            if not r.findings:
                print(f"  {status_headline(style, 'ok', 'no portability blockers found')}")
            for f in r.findings:
                level = "warn" if f.level == "warn" else "info"
                print(f"  {status_headline(style, level, f'{f.field}: {f.message}')}")

    return 1 if any_blockers else 0


def _cmd_fix(args) -> int:
    paths = _collect_paths(args.path)
    results = []
    unreadable = []
    refused = []
    for p in paths:
        try:
            dest, changes = write_portable_copy(p, args.out, strip_static_ip=args.strip_static_ip)
        except ProfileUnreadable as exc:
            unreadable.append({"source": str(p), "error": str(exc)})
            continue
        except WouldOverwriteSource as exc:
            refused.append({"source": str(p), "error": str(exc)})
            continue
        results.append({"source": str(p), "dest": str(dest), "changes": changes})

    if args.json:
        print(json.dumps({"written": results, "unreadable": unreadable, "refused": refused}, indent=2))
    else:
        if not results and not unreadable and not refused:
            print(f"No .nmconnection files found at {args.path}")
        for r in results:
            print(f"\n{r['source']} -> {r['dest']}")
            if not r["changes"]:
                print("  (no changes needed)")
            for c in r["changes"]:
                print(f"  - {c}")
        for u in unreadable:
            print(f"\n{u['source']}")
            print(f"  SKIPPED -- could not inspect this file: {u['error']}")
        for r in refused:
            print(f"\n{r['source']}")
            print(f"  REFUSED -- {r['error']}")
        print(
            f"\n{len(results)} portable copy(ies) written to {args.out}. "
            "Review before copying into /etc/NetworkManager/system-connections/ "
            "on the destination machine -- this tool never touches that "
            "directory or reloads NetworkManager itself."
        )
        if unreadable:
            print(f"{len(unreadable)} file(s) skipped because they could not be read -- see above.")
        if refused:
            print(
                f"{len(refused)} file(s) refused because --out would overwrite the "
                "original -- see above. Choose a different --out directory."
            )

    return 1 if (unreadable or refused) else 0


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "audit":
        return _cmd_audit(args)
    if args.command == "fix":
        return _cmd_fix(args)
    return 2


if __name__ == "__main__":
    sys.exit(main())
